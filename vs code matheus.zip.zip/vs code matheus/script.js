/**
 * SCRIPT.JS - INTERACOES DE TECNOLOGIA ESTELAR
 * Animacoes de alto contraste e logica tecnica da interface
 */

document.addEventListener('DOMContentLoaded', () => {
    
    // --- 1. PARTICULAS TECNICAS (MINIMALISTAS) ---
    const initParticles = () => {
        const canvas = document.getElementById('particles-canvas');
        if (!canvas) return;
        
        const ctx = canvas.getContext('2d');
        let particles = [];
        
        const resize = () => {
            canvas.width = window.innerWidth;
            canvas.height = window.innerHeight;
        };
        
        window.addEventListener('resize', resize);
        resize();
        
        class Particle {
            constructor() {
                this.reset();
            }
            
            reset() {
                this.x = Math.random() * canvas.width;
                this.y = Math.random() * canvas.height;
                this.size = Math.random() * 1 + 0.1;
                this.speedX = Math.random() * 0.2 - 0.1;
                this.speedY = Math.random() * 0.2 - 0.1;
                this.opacity = Math.random() * 0.5 + 0.1;
            }
            
            update() {
                this.x += this.speedX;
                this.y += this.speedY;
                
                if (this.x > canvas.width || this.x < 0 || this.y > canvas.height || this.y < 0) {
                    this.reset();
                }
            }
            
            draw() {
                ctx.fillStyle = `rgba(255, 255, 255, ${this.opacity})`;
                ctx.beginPath();
                // Partículas quadradas para vibe mais técnica
                ctx.rect(this.x, this.y, this.size, this.size);
                ctx.fill();
            }
        }
        
        const createParticles = () => {
            const density = (canvas.width * canvas.height) / 20000;
            for (let i = 0; i < density; i++) {
                particles.push(new Particle());
            }
        };
        
        const animate = () => {
            ctx.clearRect(0, 0, canvas.width, canvas.height);
            particles.forEach(p => {
                p.update();
                p.draw();
            });
            requestAnimationFrame(animate);
        };
        
        createParticles();
        animate();
    };
    
    initParticles();

    // --- 2. SISTEMA DE REVELACAO (SUAVE) ---
    const revealSystem = () => {
        const reveals = document.querySelectorAll('.reveal');
        const sections = document.querySelectorAll('main > section:not(#hero), .footer-noir');
        
        const observer = new IntersectionObserver((entries) => {
            entries.forEach(entry => {
                if (entry.isIntersecting) {
                    entry.target.classList.add('active');
                }
            });
        }, {
            threshold: 0.14,
            rootMargin: "0px 0px -70px 0px"
        });
        
        reveals.forEach((el, index) => {
            el.style.setProperty('--reveal-delay', `${Math.min(index % 5, 4) * 90}ms`);
            observer.observe(el);
        });

        sections.forEach(section => {
            section.classList.add('section-reveal');
            observer.observe(section);
        });
    };
    
    revealSystem();

    // --- 2.1. MOTION PROFISSIONAL GUIADO PELO SCROLL ---
    const scrollMotionSystem = () => {
        const motionGrid = document.querySelector('.motion-grid');
        const parallaxItems = document.querySelectorAll(
            '.about-card, .course-card, .ongoing-card, .skill-row, .timeline-block'
        );
        const sectionHeaders = document.querySelectorAll('.section-header');
        let ticking = false;

        parallaxItems.forEach((item, index) => {
            item.classList.add('scroll-lift');
            item.style.setProperty('--parallax-strength', String(10 + (index % 4) * 4));
        });

        sectionHeaders.forEach(header => {
            header.classList.add('reveal-left');
        });

        const clamp = (value, min, max) => Math.min(Math.max(value, min), max);

        const updateMotion = () => {
            const scrollTop = window.pageYOffset || document.documentElement.scrollTop;
            const maxScroll = Math.max(document.documentElement.scrollHeight - window.innerHeight, 1);
            const depth = clamp(scrollTop / maxScroll, 0, 1);

            if (motionGrid) {
                motionGrid.style.setProperty('--scroll-depth', depth.toFixed(4));
                motionGrid.style.opacity = String(clamp(0.22 + depth * 0.28, 0.22, 0.5));
            }

            parallaxItems.forEach(item => {
                const rect = item.getBoundingClientRect();
                const centerOffset = (rect.top + rect.height / 2) - (window.innerHeight / 2);
                const strength = Number(item.style.getPropertyValue('--parallax-strength')) || 12;
                const lift = clamp(centerOffset / window.innerHeight, -1, 1) * strength;
                item.style.setProperty('--scroll-lift', `${lift.toFixed(2)}px`);
            });

            ticking = false;
        };

        const requestMotion = () => {
            if (!ticking) {
                requestAnimationFrame(updateMotion);
                ticking = true;
            }
        };

        window.addEventListener('scroll', requestMotion, { passive: true });
        window.addEventListener('resize', requestMotion);
        requestMotion();
    };

    scrollMotionSystem();

    // --- 2.2. SCROLL SUAVE E MICRO INTERACAO DO CABECALHO ---
    const headerSmoothNavigation = () => {
        const reduceMotion = window.matchMedia('(prefers-reduced-motion: reduce)').matches;

        document.querySelectorAll('.glass-nav a[href^="#"]').forEach(link => {
            link.addEventListener('click', event => {
                const target = document.querySelector(link.getAttribute('href'));
                if (!target) return;

                event.preventDefault();
                link.classList.add('nav-clicked');
                target.scrollIntoView({
                    behavior: reduceMotion ? 'auto' : 'smooth',
                    block: 'start'
                });

                setTimeout(() => {
                    link.classList.remove('nav-clicked');
                }, 650);
            });
        });
    };

    headerSmoothNavigation();

    // --- 3. EFEITOS DE ROLAGEM DA NAVEGACAO ---
    const navScroll = () => {
        const nav = document.querySelector('.glass-nav');
        const sections = document.querySelectorAll('section');
        const navItems = document.querySelectorAll('.nav-item');
        
        window.addEventListener('scroll', () => {
            if (window.scrollY > 50) {
                nav.style.background = 'rgba(0, 0, 0, 0.9)';
                nav.style.padding = '0.8rem 0';
            } else {
                nav.style.background = 'rgba(0, 0, 0, 0.8)';
                nav.style.padding = '1.2rem 0';
            }
            
            // Link ativo
            let current = "";
            sections.forEach(section => {
                const sectionTop = section.offsetTop;
                if (pageYOffset >= sectionTop - 150) {
                    current = section.getAttribute("id");
                }
            });
            
            navItems.forEach(item => {
                item.classList.remove("active");
                if (item.getAttribute("href").includes(current)) {
                    item.classList.add("active");
                }
            });
        });
    };
    
    navScroll();

    // --- 3.1. SCROLL PROGRESS BAR ---
    const scrollProgress = () => {
        const progressBar = document.getElementById('progress-bar');
        window.addEventListener('scroll', () => {
            const scrollTop = window.pageYOffset || document.documentElement.scrollTop;
            const scrollHeight = document.documentElement.scrollHeight - window.innerHeight;
            const progress = (scrollTop / scrollHeight) * 100;
            progressBar.style.width = progress + '%';
        });
    };

    scrollProgress();

    // --- 3.2. TYPEWRITER EFFECT FOR HERO ---
    const typewriter = () => {
        const heroTitle = document.querySelector('.hero-title .text-outline');
        if (!heroTitle) return;
        
        const text = "Desenvolvedor de Sistemas";
        let i = 0;
        heroTitle.textContent = '';
        
        const type = () => {
            if (i < text.length) {
                heroTitle.textContent += text.charAt(i);
                i++;
                setTimeout(type, 100);
            }
        };
        
        setTimeout(type, 1000);
    };

    typewriter();

    // --- 4. ANIMACAO DAS BARRAS TECNICAS ---
    const animateBars = () => {
        const bars = document.querySelectorAll('.skill-fill-white, .progress-fill-white');
        
        const barObserver = new IntersectionObserver((entries) => {
            entries.forEach(entry => {
                if (entry.isIntersecting) {
                    const width = entry.target.style.width;
                    entry.target.style.width = '0';
                    setTimeout(() => {
                        entry.target.style.transition = 'width 2.5s cubic-bezier(0.2, 1, 0.3, 1)';
                        entry.target.style.width = width;
                    }, 300);
                    barObserver.unobserve(entry.target);
                }
            });
        }, { threshold: 0.5 });
        
        bars.forEach(bar => barObserver.observe(bar));
    };
    
    animateBars();

    // --- 5. PARALAXE ESTELAR ---
    window.addEventListener('scroll', () => {
        const heroTitle = document.querySelector('.hero-title');
        if (heroTitle) {
            let scroll = window.pageYOffset;
            heroTitle.style.transform = `translateY(${scroll * 0.2}px)`;
            heroTitle.style.opacity = 1 - (scroll / 800);
        }
    });

    // --- 6. INTERACAO DO CURSOR (SUTIL) ---
    // Adiciona um pequeno rastro ou efeito de hover nos cards
    const cards = document.querySelectorAll('.course-card');
    cards.forEach(card => {
        card.addEventListener('mousemove', (e) => {
            const rect = card.getBoundingClientRect();
            const x = e.clientX - rect.left;
            const y = e.clientY - rect.top;
            
            const overlay = card.querySelector('.course-overlay');
            if (overlay) {
                overlay.style.background = `radial-gradient(circle at ${x}px ${y}px, rgba(255,255,255,0.08) 0%, transparent 70%)`;
            }
        });
    });

});
