/**
 * FAZ ACONTECE - SOFTWARE HOUSE ENGINE
 * Controle de interações dinâmicas, gerenciador de temas, renderizador de modais e validação estruturada.
 */

document.addEventListener('DOMContentLoaded', () => {
    initThemeEngine();
    initMobileMenu();
    initScrollTracker();
    initContactValidator();
    initModalPortfolioEngine();
});

/**
 * 🌗 THEME ENGINE SYSTEM (MODO CLARO E ESCURO)
 * Altera classes raiz e persiste dados locais através da API LocalStorage.
 */
function initThemeEngine() {
    const themeBtn = document.getElementById('theme-toggle');
    const bodyElement = document.body;
    
    // Confere cache local para persistência de dados
    const savedTheme = localStorage.getItem('faz-acontece-theme') || 'dark';
    
    if (savedTheme === 'light') {
        bodyElement.className = 'light-theme';
        themeBtn.innerHTML = `<i class="fa-solid fa-sun"></i>`;
    } else {
        bodyElement.className = 'dark-theme';
        themeBtn.innerHTML = `<i class="fa-solid fa-moon"></i>`;
    }

    themeBtn.addEventListener('click', () => {
        if (bodyElement.classList.contains('dark-theme')) {
            bodyElement.className = 'light-theme';
            themeBtn.innerHTML = `<i class="fa-solid fa-sun"></i>`;
            localStorage.setItem('faz-acontece-theme', 'light');
        } else {
            bodyElement.className = 'dark-theme';
            themeBtn.innerHTML = `<i class="fa-solid fa-moon"></i>`;
            localStorage.setItem('faz-acontece-theme', 'dark');
        }
    });
}

/**
 * 📱 MOBILE MENU ROUTER INTERACTION
 */
function initMobileMenu() {
    const toggleBtn = document.getElementById('mobile-menu-toggle');
    const navMenu = document.getElementById('nav-menu');
    const menuLinks = document.querySelectorAll('.nav-link');

    function closeMenu() {
        toggleBtn.classList.remove('active');
        navMenu.classList.remove('active');
    }

    toggleBtn.addEventListener('click', () => {
        toggleBtn.classList.toggle('active');
        navMenu.classList.toggle('active');
    });

    menuLinks.forEach(link => {
        link.addEventListener('click', () => {
            closeMenu();
        });
    });

    // Fecha se o usuário clicar no background da página fora do menu aberto
    document.addEventListener('click', (e) => {
        if (!navMenu.contains(e.target) && !toggleBtn.contains(e.target) && navMenu.classList.contains('active')) {
            closeMenu();
        }
    });
}

/**
 * 👁️ SCROLL INTERACTION & REVEAL ENGINE
 * Gerencia o aparecimento suave de seções e atualiza o menu ativo conforme posição no scroll.
 */
function initScrollTracker() {
    const revealItems = document.querySelectorAll('.scroll-reveal');
    const navLinks = document.querySelectorAll('.nav-link');
    const sections = document.querySelectorAll('section');

    const observerOptions = {
        root: null,
        threshold: 0.12,
        rootMargin: "0px"
    };

    // Callback para revelar elementos com scroll
    const revealObserver = new IntersectionObserver((entries) => {
        entries.forEach(entry => {
            if (entry.isIntersecting) {
                entry.target.classList.add('revealed');
                revealObserver.unobserve(entry.target); // Unobserve após revelar
            }
        });
    }, observerOptions);

    revealItems.forEach(item => {
        revealObserver.observe(item);
    });

    // Callback para rastrear indicador ativo do menu
    window.addEventListener('scroll', () => {
        let activeSectionId = "";
        const scrollPosition = window.scrollY + 120; // Offset fixo compensando header

        sections.forEach(section => {
            const sectionTop = section.offsetTop;
            const sectionHeight = section.offsetHeight;
            if (scrollPosition >= sectionTop && scrollPosition < (sectionTop + sectionHeight)) {
                activeSectionId = section.getAttribute('id');
            }
        });

        navLinks.forEach(link => {
            link.classList.remove('active');
            if (link.getAttribute('href') === `#${activeSectionId}`) {
                link.classList.add('active');
            }
        });
    });
}

/**
 * 🛡️ FORM VALIDATION ENGINE (CONTATO PROFISSIONAL)
 */
function initContactValidator() {
    const form = document.getElementById('main-contact-form');
    
    if (!form) return;

    const inputs = form.querySelectorAll('input[required], textarea[required]');

    inputs.forEach(input => {
        // Remove estado inválido ao digitar
        input.addEventListener('input', () => {
            if (input.value.trim() !== '') {
                input.parentElement.classList.remove('invalid');
            }
        });
    });

    form.addEventListener('submit', (e) => {
        e.preventDefault();
        let isFormValid = true;

        inputs.forEach(input => {
            const group = input.parentElement;
            
            // Validação genérica de campo vazio
            if (input.value.trim() === '') {
                group.classList.add('invalid');
                isFormValid = false;
            } else {
                group.classList.remove('invalid');
            }

            // Regra específica para estrutura de e-mail regular
            if (input.type === 'email' && input.value.trim() !== '') {
                const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
                if (!emailRegex.test(input.value.trim())) {
                    group.classList.add('invalid');
                    isFormValid = false;
                }
            }
        });

        if (isFormValid) {
            const submitBtn = form.querySelector('button[type="submit"]');
            const originalContent = submitBtn.innerHTML;
            
            // Estado visual de carregamento
            submitBtn.disabled = true;
            submitBtn.innerHTML = `<i class="fa-solid fa-circle-notch fa-spin"></i> Processando...`;

            setTimeout(() => {
                // Simulação de sucesso pós processamento assíncrono
                form.reset();
                submitBtn.innerHTML = `<i class="fa-solid fa-check-double"></i> Enviado com Sucesso!`;
                submitBtn.style.backgroundColor = '#10B981';
                
                setTimeout(() => {
                    submitBtn.disabled = false;
                    submitBtn.innerHTML = originalContent;
                    submitBtn.style.backgroundColor = '';
                }, 3000);
            }, 1500);
        }
    });
}

/**
 * 📦 DYNAMIC MODAL ENGINE (PORTFÓLIO DE PROJETOS)
 * Elimina dados fixos do HTML e constrói layouts dinamicamente com base no dataset do elemento.
 */
function initModalPortfolioEngine() {
    const modal = document.getElementById('project-modal');
    const closeBtn = document.getElementById('modal-close-btn');
    const triggers = document.querySelectorAll('.open-modal-trigger');
    const dynamicContainer = document.getElementById('modal-dynamic-content');

    // Dicionário estruturado de dados simulando banco relacional externo
    const projectDatabase = {
        cadastro: {
            title: "Sistema Integrado de Cadastro",
            category: "Aplicações Web / SENAI",
            desc: "Plataforma completa de processamento de cadastros empresariais estruturada sob critérios rígidos de arquitetura limpa. Conta com rotinas automáticas de sanitização de dados de entrada e proteção nativa contra injeções de scripts maliciosos.",
            techs: ["Node.js", "JavaScript", "MySQL", "Git"],
            features: ["Validação assíncrona de duplicidades", "Mapeamento relacional de tabelas", "Exportação estruturada de relatórios XLS"]
        },
        landing: {
            title: "Landing Page Responsiva Premium",
            category: "Design & Performance / SENAI",
            desc: "Página de aterrissagem estruturada focada em conversão para produtos high-ticket. Código sem dependências de frameworks pesados, garantindo carregamento ultrarrápido (Core Web Vitals nota máxima) e adaptação pixel-perfect em qualquer tamanho de tela.",
            techs: ["HTML5", "CSS3", "Figma", "GitHub"],
            features: ["Layout fluido baseado em CSS Grid", "Imagens inteligentes otimizadas em WebP", "Acessibilidade estrutural garantida por tags ARIA"]
        },
        gestao: {
            title: "Plataforma de Gestão Corporativa",
            category: "Sistemas Web / SENAI",
            desc: "Painel administrativo desenhado para otimizar fluxos corporativos internos. Permite que gestores monitorem indicadores-chave operacionais e gerenciem permissões granulares de visualização e edição de relatórios financeiros.",
            techs: ["JavaScript", "Node.js", "MySQL", "Git"],
            features: ["Gráficos dinâmicos interativos", "Autenticação em múltiplos níveis", "Logs automatizados de auditoria interna"]
        }
    };

    function openModal(projectId) {
        const data = projectDatabase[projectId];
        if (!data) return;

        // Montagem do template de visualização do projeto
        dynamicContainer.innerHTML = `
            <div class="modal-body-content">
                <span class="p-tag">${data.category}</span>
                <h3>${data.title}</h3>
                <p>${data.desc}</p>
                
                <div class="modal-tech-list">
                    <h4>Tecnologias Envolvidas:</h4>
                    <div>
                        ${data.techs.map(t => `<span>${t}</span>`).join('')}
                    </div>
                </div>

                <div class="modal-features-list">
                    <h4>Destaques Técnicos do Projeto:</h4>
                    <ul>
                        ${data.features.map(f => `<li><i class="fa-solid fa-circle-check"></i> ${f}</li>`).join('')}
                    </ul>
                </div>
            </div>
        `;

        modal.classList.add('active');
        modal.setAttribute('aria-hidden', 'false');
        document.body.style.overflow = 'hidden'; // Trava o scroll da página de fundo
    }

    function closeModal() {
        modal.classList.remove('active');
        modal.setAttribute('aria-hidden', 'true');
        document.body.style.overflow = '';
    }

    triggers.forEach(trigger => {
        trigger.addEventListener('click', () => {
            const projectId = trigger.getAttribute('data-project');
            openModal(projectId);
        });
    });

    closeBtn.addEventListener('click', closeModal);
    
    // Fecha clicando fora do card no overlay
    modal.addEventListener('click', (e) => {
        if (e.target === modal) closeModal();
    });

    // Atalho tecla ESC para fechar modal
    window.addEventListener('keydown', (e) => {
        if (e.key === 'Escape' && modal.classList.contains('active')) closeModal();
    });
}