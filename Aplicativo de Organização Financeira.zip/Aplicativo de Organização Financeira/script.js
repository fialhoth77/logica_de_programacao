document.addEventListener('DOMContentLoaded', () => {

    // ==========================================
    // THEME SYSTEM
    // ==========================================
    const themeButtons = document.querySelectorAll('.theme-toggle');
    const systemPrefersLight = window.matchMedia && window.matchMedia('(prefers-color-scheme: light)').matches;
    const savedTheme = localStorage.getItem('vf-theme');
    const initialTheme = savedTheme || (systemPrefersLight ? 'light' : 'dark');

    const applyTheme = (theme) => {
        document.documentElement.setAttribute('data-theme', theme);
        localStorage.setItem('vf-theme', theme);
        themeButtons.forEach((button) => {
            const isLight = theme === 'light';
            button.setAttribute('aria-pressed', String(isLight));
            button.innerHTML = isLight ? '<i class="fa-solid fa-sun"></i>' : '<i class="fa-solid fa-moon"></i>';
        });
    };

    applyTheme(initialTheme);

    themeButtons.forEach((button) => {
        button.addEventListener('click', () => {
            const currentTheme = document.documentElement.getAttribute('data-theme') || 'dark';
            applyTheme(currentTheme === 'dark' ? 'light' : 'dark');
        });
    });

    // ==========================================
    // MOBILE NAVIGATION COMPONENT
    // ==========================================
    const mobileMenuToggle = document.querySelector('.mobile-menu-toggle');
    const navMenu = document.querySelector('.nav-menu');
    
    if (mobileMenuToggle) {
        mobileMenuToggle.addEventListener('click', () => {
            // Alternância simples para fins demonstrativos estruturais
            const isVisible = navMenu.classList.contains('is-open');
            navMenu.classList.toggle('is-open', !isVisible);
            navMenu.style.display = '';
            if (!isVisible) {
                navMenu.style.position = 'absolute';
                navMenu.style.top = '100%';
                navMenu.style.left = '0';
                navMenu.style.width = '100%';
                navMenu.style.flexDirection = 'column';
                navMenu.style.background = 'var(--bg-surface)';
                navMenu.style.padding = '20px';
                navMenu.style.borderBottom = '1px solid rgba(255,255,255,0.08)';
            }
        });
    }

    // ==========================================
    // ANIMATION & REVEAL ON SCROLL SYSTEM
    // ==========================================
    const revealElements = document.querySelectorAll('.reveal');
    
    const revealOnScroll = () => {
        const triggerBottom = window.innerHeight * 0.85;
        
        revealElements.forEach(element => {
            const elementTop = element.getBoundingClientRect().top;
            if (elementTop < triggerBottom) {
                element.classList.add('active');
            }
        });
    };
    
    window.addEventListener('scroll', revealOnScroll);
    revealOnScroll(); // Disparo inicial para elementos acima da dobra

    // ==========================================
    // NUMERICAL ANIMATION (COUNTER EFFECT)
    // ==========================================
    const statsNumbers = document.querySelectorAll('.stat-number');
    const currencyStats = document.querySelectorAll('.stat-number-currency');
    let countersStarted = false;

    const startCounters = () => {
        // Contador Padrão
        statsNumbers.forEach(stat => {
            const target = parseInt(stat.getAttribute('data-target'), 10);
            let count = 0;
            const speed = target / 60; // Duração base
            
            const updateCount = () => {
                count += speed;
                if (count < target) {
                    stat.innerText = `+${Math.floor(count).toLocaleString('pt-BR')}`;
                    setTimeout(updateCount, 15);
                } else {
                    stat.innerText = `+${target.toLocaleString('pt-BR')}`;
                }
            };
            updateCount();
        });

        // Contador de Moeda Comercial/Patrimônio
        currencyStats.forEach(stat => {
            const target = parseInt(stat.getAttribute('data-target'), 10);
            let count = 0;
            const updateCurrency = () => {
                count += 0.05;
                if (count < target) {
                    stat.innerText = `R$ ${count.toFixed(1)} Bilhões`;
                    setTimeout(updateCurrency, 30);
                } else {
                    stat.innerText = `R$ ${target} Bilhões`;
                }
            };
            updateCurrency();
        });
    };

    // Monitoramento do scroll para iniciar o contador ao atingir a seção hero
    setTimeout(() => {
        if (!countersStarted) {
            startCounters();
            countersStarted = true;
        }
    }, 400);

    // ==========================================
    // SIMULATED REAL-TIME MARKET SYNC
    // ==========================================
    const updateMarketSim = () => {
        // Seletores de cotação de mercado
        const btcPrice = document.querySelector('#ticker-btc .ticker-price');
        const usdPrice = document.querySelector('#ticker-usd .ticker-price');
        const petrPrice = document.querySelector('#asset-petr4 .asset-price');

        if (btcPrice) {
            const currentBtc = 64250 + (Math.random() * 80 - 40);
            btcPrice.innerText = `US$ ${Math.floor(currentBtc).toLocaleString('en-US')}`;
        }
        if (usdPrice) {
            const currentUsd = 5.24 + (Math.random() * 0.02 - 0.01);
            usdPrice.innerText = `R$ ${currentUsd.toFixed(2)}`;
        }
        if (petrPrice) {
            const currentPetr = 38.40 + (Math.random() * 0.14 - 0.07);
            petrPrice.innerText = `R$ ${currentPetr.toFixed(2)}`;
        }
    };

    // Atualização em intervalos regulares (Simulação estável do Websocket institucional)
    setInterval(updateMarketSim, 3500);

    // ==========================================
    // INTERACTIVE ADVISOR CHAT COMPONENT
    // ==========================================
    const chatBody = document.getElementById('chat-body');
    const suggestButtons = document.querySelectorAll('.chat-suggest-btn');

    const advisorResponses = {
        exterior: "Investimentos internacionais mitigam o risco soberano de uma única moeda. Na Vermelion, a alocação externa via ativos globais (BDRs ou contas integradas) reduz volatilidades do seu caixa primário através de diversificação sistêmica.",
        proporcao: "Recomendamos que a reserva estratégica de liquidez cubra entre 6 a 12 meses dos custos fixos operacionais. Esse capital deve permanecer em fundos de Renda Fixa High Liquidity antes de avançar para a renda variável."
    };

    suggestButtons.forEach(btn => {
        btn.addEventListener('click', (e) => {
            const questionType = e.target.getAttribute('data-question');
            const questionText = e.target.innerText;

            if (advisorResponses[questionType]) {
                // Remove botões para simular o andamento natural do fluxo
                e.target.style.opacity = '0.5';
                e.target.style.pointerEvents = 'none';

                // Append Mensagem Usuário
                const userMsg = document.createElement('div');
                userMsg.className = 'chat-msg user';
                userMsg.innerHTML = `<div class="msg-bubble">${questionText}</div>`;
                chatBody.appendChild(userMsg);

                // Auto Scroll
                chatBody.scrollTop = chatBody.scrollHeight;

                // Delay simulado de digitação analítica
                setTimeout(() => {
                    const systemMsg = document.createElement('div');
                    systemMsg.className = 'chat-msg system';
                    systemMsg.innerHTML = `<div class="msg-bubble">${advisorResponses[questionType]}</div>`;
                    chatBody.appendChild(systemMsg);
                    chatBody.scrollTop = chatBody.scrollHeight;
                }, 900);
            }
        });
    });

    // ==========================================
    // BUTTON FEEDBACK, MODALS & AUTH FLOW
    // ==========================================
    const showToast = (message, type = 'success') => {
        let stack = document.querySelector('.toast-stack');
        if (!stack) {
            stack = document.createElement('div');
            stack.className = 'toast-stack';
            document.body.appendChild(stack);
        }

        const toast = document.createElement('div');
        toast.className = `toast toast-${type}`;
        toast.innerHTML = `<i class="fa-solid ${type === 'error' ? 'fa-circle-exclamation' : 'fa-circle-check'}"></i><span>${message}</span>`;
        stack.appendChild(toast);
        setTimeout(() => toast.classList.add('show'), 20);
        setTimeout(() => {
            toast.classList.remove('show');
            setTimeout(() => toast.remove(), 250);
        }, 3200);
    };

    document.querySelectorAll('.btn').forEach((button) => {
        button.addEventListener('click', () => {
            button.classList.add('is-clicked');
            setTimeout(() => button.classList.remove('is-clicked'), 260);
        });
    });

    const modalContent = {
        termos: {
            title: 'Termos de Uso',
            text: 'Ao usar a Vermelion Finance, você concorda com uma experiência demonstrativa de gestão financeira, com dados simulados e foco em organização, educação e acompanhamento patrimonial.'
        },
        privacidade: {
            title: 'Política de Privacidade',
            text: 'Suas informações visuais são tratadas com foco em segurança. Nesta versão estática, os dados de acesso são mantidos localmente no navegador para simular persistência.'
        }
    };

    document.querySelectorAll('[data-info-modal]').forEach((link) => {
        link.addEventListener('click', (event) => {
            event.preventDefault();
            const info = modalContent[link.dataset.infoModal];
            if (!info) return;

            const modal = document.createElement('div');
            modal.className = 'info-modal';
            modal.innerHTML = `
                <div class="info-modal-card" role="dialog" aria-modal="true" aria-label="${info.title}">
                    <button type="button" class="info-modal-close" aria-label="Fechar"><i class="fa-solid fa-xmark"></i></button>
                    <span class="section-tag">Legal</span>
                    <h3>${info.title}</h3>
                    <p>${info.text}</p>
                </div>
            `;
            document.body.appendChild(modal);
            setTimeout(() => modal.classList.add('show'), 20);

            const closeModal = () => {
                modal.classList.remove('show');
                setTimeout(() => modal.remove(), 220);
            };

            modal.addEventListener('click', (clickEvent) => {
                if (clickEvent.target === modal) closeModal();
            });
            modal.querySelector('.info-modal-close').addEventListener('click', closeModal);
        });
    });

    const authPanels = document.querySelectorAll('[data-auth-panel]');
    const authTabs = document.querySelectorAll('[data-auth-tab]');
    const authOpeners = document.querySelectorAll('[data-auth-open]');
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;

    const openAuthPanel = (panelName) => {
        if (!authPanels.length) return;
        authPanels.forEach((panel) => panel.classList.toggle('active', panel.dataset.authPanel === panelName));
        authTabs.forEach((tab) => tab.classList.toggle('active', tab.dataset.authTab === panelName));
        const url = new URL(window.location.href);
        url.searchParams.set('mode', panelName);
        window.history.replaceState({}, '', url);
    };

    const getPasswordScore = (password) => {
        let score = 0;
        if (password.length >= 8) score += 1;
        if (/[A-Z]/.test(password)) score += 1;
        if (/[0-9]/.test(password)) score += 1;
        if (/[^A-Za-z0-9]/.test(password)) score += 1;
        return score;
    };

    const setFieldState = (input, valid, message) => {
        const group = input.closest('.field-group');
        const fieldMessage = group?.querySelector('.field-message');
        if (!group || !fieldMessage) return valid;
        group.classList.toggle('is-valid', valid);
        group.classList.toggle('is-invalid', !valid && Boolean(input.value.trim()));
        fieldMessage.textContent = message;
        return valid;
    };

    const validateInput = (input, form) => {
        const value = input.value.trim();
        if (input.name === 'name') {
            return setFieldState(input, value.split(' ').filter(Boolean).length >= 2, 'Informe nome e sobrenome.');
        }
        if (input.type === 'email') {
            return setFieldState(input, emailRegex.test(value), 'Digite um e-mail válido.');
        }
        if (input.name === 'password') {
            const score = getPasswordScore(input.value);
            const strength = input.closest('.field-group')?.querySelector('.password-strength span');
            if (strength) {
                strength.style.width = `${Math.max(score, 1) * 25}%`;
                strength.dataset.score = String(score);
            }
            return setFieldState(input, score >= 3, 'Use 8 caracteres, maiúscula, número e símbolo.');
        }
        if (input.name === 'confirm') {
            const password = form.querySelector('input[name="password"]')?.value || '';
            return setFieldState(input, input.value === password && input.value.length > 0, 'As senhas precisam ser iguais.');
        }
        return setFieldState(input, Boolean(value), 'Campo obrigatório.');
    };

    authTabs.forEach((tab) => tab.addEventListener('click', () => openAuthPanel(tab.dataset.authTab)));
    authOpeners.forEach((opener) => opener.addEventListener('click', () => openAuthPanel(opener.dataset.authOpen)));

    document.querySelectorAll('.toggle-password').forEach((button) => {
        button.addEventListener('click', () => {
            const input = button.closest('.password-wrap')?.querySelector('input');
            if (!input) return;
            const showPassword = input.type === 'password';
            input.type = showPassword ? 'text' : 'password';
            button.innerHTML = showPassword ? '<i class="fa-solid fa-eye-slash"></i>' : '<i class="fa-solid fa-eye"></i>';
        });
    });

    document.querySelectorAll('.auth-form input').forEach((input) => {
        input.addEventListener('input', () => validateInput(input, input.closest('form')));
        input.addEventListener('blur', () => validateInput(input, input.closest('form')));
    });

    document.querySelectorAll('.auth-form').forEach((form) => {
        form.addEventListener('submit', (event) => {
            event.preventDefault();
            const fields = [...form.querySelectorAll('input[required]')];
            const results = fields.map((input) => validateInput(input, form));
            const isValid = results.every(Boolean);
            const submit = form.querySelector('.auth-submit');

            if (!isValid) {
                showToast('Revise os campos destacados para continuar.', 'error');
                return;
            }

            submit.classList.add('is-loading');
            const originalContent = submit.innerHTML;
            submit.innerHTML = '<i class="fa-solid fa-spinner fa-spin"></i> Processando';

            setTimeout(() => {
                submit.classList.remove('is-loading');
                submit.innerHTML = originalContent;

                if (form.id === 'register-form') {
                    localStorage.setItem('vf-user', JSON.stringify({
                        name: form.elements.name.value.trim(),
                        email: form.elements.email.value.trim()
                    }));
                    showToast('Conta criada com sucesso. Você já pode entrar.');
                    openAuthPanel('login');
                    return;
                }

                if (form.id === 'login-form') {
                    localStorage.setItem('vf-session', JSON.stringify({
                        email: form.elements.email.value.trim(),
                        persistent: form.elements.remember.checked,
                        createdAt: new Date().toISOString()
                    }));
                    showToast('Login realizado com sucesso.');
                    return;
                }

                if (form.id === 'recover-form') {
                    showToast('Instruções enviadas. Avance para redefinir a senha.');
                    openAuthPanel('redefinir');
                    return;
                }

                if (form.id === 'reset-form') {
                    showToast('Senha redefinida com sucesso.');
                    openAuthPanel('login');
                }
            }, 850);
        });
    });

    const requestedAuthMode = new URLSearchParams(window.location.search).get('mode');
    if (authPanels.length) {
        openAuthPanel(requestedAuthMode || 'login');
    }
});
