/**
 * APEX FITNESS - CORE INTERACTIVE ENGINE
 */

document.addEventListener('DOMContentLoaded', () => {

    // 1. DISMISS PRELOADER
    const preloader = document.getElementById('preloader');
    if (preloader) {
        window.addEventListener('load', () => {
            setTimeout(() => {
                preloader.classList.add('fade-out');
            }, 600);
        });
    }

    // 2. MENU MOBILE INTERATIVO (HAMBURGER)
    const hamburger = document.getElementById('hamburger-menu');
    const navMenu = document.getElementById('nav-menu');
    
    if (hamburger && navMenu) {
        hamburger.addEventListener('click', () => {
            navMenu.classList.toggle('open');
            const bars = hamburger.querySelectorAll('.bar');
            bars[0].style.transform = navMenu.classList.contains('open') ? 'rotate(45deg) translate(6px, 6px)' : 'none';
            bars[1].style.opacity = navMenu.classList.contains('open') ? '0' : '1';
            bars[2].style.transform = navMenu.classList.contains('open') ? 'rotate(-45deg) translate(5px, -5px)' : 'none';
        });

        // Fecha o menu ao clicar em qualquer item de link
        const navLinks = document.querySelectorAll('.nav-link');
        navLinks.forEach(link => {
            link.addEventListener('click', () => {
                navMenu.classList.remove('open');
                const bars = hamburger.querySelectorAll('.bar');
                bars[0].style.transform = 'none';
                bars[1].style.opacity = '1';
                bars[2].style.transform = 'none';
            });
        });
    }

    // 2.1. NAVEGACAO SUAVE COM DESTAQUE DA SECAO
    const internalLinks = document.querySelectorAll('a[href^="#"]');
    const closeMobileMenu = () => {
        if (!hamburger || !navMenu) return;

        navMenu.classList.remove('open');
        const bars = hamburger.querySelectorAll('.bar');
        bars[0].style.transform = 'none';
        bars[1].style.opacity = '1';
        bars[2].style.transform = 'none';
    };

    internalLinks.forEach(link => {
        link.addEventListener('click', (event) => {
            const targetId = link.getAttribute('href');
            if (!targetId || targetId === '#') return;

            const targetSection = document.querySelector(targetId);
            if (!targetSection) return;

            event.preventDefault();
            closeMobileMenu();

            const headerOffset = header ? header.offsetHeight + 18 : 0;
            const targetPosition = targetSection.getBoundingClientRect().top + window.scrollY - headerOffset;

            window.scrollTo({
                top: targetPosition,
                behavior: 'smooth'
            });

            targetSection.classList.remove('scroll-target-highlight');
            setTimeout(() => targetSection.classList.add('scroll-target-highlight'), 450);
            setTimeout(() => targetSection.classList.remove('scroll-target-highlight'), 1800);
        });
    });

    // 3. EFEITO DE SCROLL NO HEADER (BLUR / GLOW)
    const header = document.getElementById('header');
    if (header) {
        window.addEventListener('scroll', () => {
            if (window.scrollY > 50) {
                header.classList.add('scrolled');
            } else {
                header.classList.remove('scrolled');
            }
        });
    }

    // 4. SISTEMA ANIMAÇÃO FADE-IN AO SCROLL (REVEAL)
    const revealItems = document.querySelectorAll('.reveal-item');
    
    const revealOnScroll = () => {
        const triggerBottom = window.innerHeight * 0.85;
        
        revealItems.forEach(item => {
            const itemTop = item.getBoundingClientRect().top;
            if (itemTop < triggerBottom) {
                item.classList.add('active');
            }
        });
    };

    window.addEventListener('scroll', revealOnScroll);
    setTimeout(revealOnScroll, 800); // Trigger inicial

    // 5. SISTEMA DO CONTADOR DE ALUNOS ANIMADO
    const counters = document.querySelectorAll('.counter-number');
    let counterAnimated = false;

    const animateCounters = () => {
        counters.forEach(counter => {
            const target = parseInt(counter.getAttribute('data-target'));
            let current = 0;
            const increment = target / 100;
            const speed = 15;

            const updateCount = () => {
                if (current < target) {
                    current += increment;
                    counter.innerText = Math.ceil(current).toLocaleString('pt-BR');
                    setTimeout(updateCount, speed);
                } else {
                    counter.innerText = target.toLocaleString('pt-BR');
                }
            };
            updateCount();
        });
    };

    // Dispara animação apenas quando o contador estiver visível na tela
    const checkCounterVisibility = () => {
        if (counters.length === 0 || counterAnimated) return;
        
        const counterBox = document.querySelector('.counter-box');
        if (counterBox) {
            const boxTop = counterBox.getBoundingClientRect().top;
            if (boxTop < window.innerHeight) {
                animateCounters();
                counterAnimated = true;
            }
        }
    };
    
    window.addEventListener('scroll', checkCounterVisibility);
    setTimeout(checkCounterVisibility, 1000);

    // 6. LINK DA RELEVANTE SEÇÃO ATIVA NA HISTÓRIA DE NAVEGAÇÃO
    const sections = document.querySelectorAll('section');
    const navLinks = document.querySelectorAll('.nav-link');

    window.addEventListener('scroll', () => {
        let currentSectionId = 'home';
        
        sections.forEach(section => {
            const sectionTop = section.offsetTop;
            if (window.scrollY >= (sectionTop - 200)) {
                currentSectionId = section.getAttribute('id');
            }
        });

        navLinks.forEach(link => {
            link.classList.remove('active');
            if (link.getAttribute('href') === `#${currentSectionId}`) {
                link.classList.add('active');
            }
        });
    });

    // 7. RESUMO DINAMICO DO CHECKOUT
    const checkoutPlanName = document.getElementById('checkout-plan-name');
    const checkoutPlanDesc = document.getElementById('checkout-plan-desc');
    const checkoutPlanPrice = document.getElementById('checkout-plan-price');
    const checkoutTotal = document.getElementById('checkout-total');

    if (checkoutPlanName && checkoutPlanDesc && checkoutPlanPrice && checkoutTotal) {
        const plans = {
            start: {
                name: 'Plano Start',
                desc: 'O ponto de partida para sua nova jornada fisica.',
                price: '79'
            },
            pro: {
                name: 'Plano Pro',
                desc: 'O equilibrio perfeito entre diversidade e alta performance.',
                price: '119'
            },
            elite: {
                name: 'Plano Elite',
                desc: 'Para quem exige o melhor e nao aceita menos que o topo.',
                price: '179'
            }
        };

        const params = new URLSearchParams(window.location.search);
        const selectedPlan = plans[params.get('plano')] || plans.pro;

        checkoutPlanName.textContent = selectedPlan.name;
        checkoutPlanDesc.textContent = selectedPlan.desc;
        checkoutPlanPrice.textContent = selectedPlan.price;
        checkoutTotal.textContent = `R$ ${selectedPlan.price}`;
    }

    const checkoutForm = document.querySelector('.checkout-form');
    if (checkoutForm) {
        checkoutForm.addEventListener('submit', (event) => {
            event.preventDefault();

            const submitButton = checkoutForm.querySelector('.checkout-submit');
            const note = checkoutForm.querySelector('.checkout-note');

            if (submitButton) {
                submitButton.textContent = 'Solicitacao enviada';
            }

            if (note) {
                note.textContent = 'Recebemos seus dados. A equipe APEX entrara em contato pelo WhatsApp para concluir sua matricula.';
            }
        });
    }
});
